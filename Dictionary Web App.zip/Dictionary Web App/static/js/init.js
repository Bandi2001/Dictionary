$(document).ready(function() {
  $('.tooltipped').tooltip({
    delay: 50,
    html: true
  });
});

  (function($){
    $(function(){

      $('.sidenav').sidenav();

    }); // end of document ready
  })(jQuery); // end of jQuery name space
